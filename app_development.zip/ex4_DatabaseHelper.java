// Exercise 4: Library Database Application
// File: app/src/main/java/com/example/library/DatabaseHelper.java

package com.example.library;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME    = "LibraryDB";
    private static final int    DB_VERSION = 1;

    // Books table
    public static final String TABLE_BOOKS  = "books";
    public static final String COL_ID       = "id";
    public static final String COL_TITLE    = "title";
    public static final String COL_AUTHOR   = "author";
    public static final String COL_STATUS   = "status";   // "available", "lent", "reserved"
    public static final String COL_STUDENT  = "student_id"; // who has it

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_BOOKS + " ("
                + COL_ID      + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_TITLE   + " TEXT NOT NULL, "
                + COL_AUTHOR  + " TEXT NOT NULL, "
                + COL_STATUS  + " TEXT DEFAULT 'available', "
                + COL_STUDENT + " TEXT DEFAULT '' )";
        db.execSQL(CREATE_TABLE);

        // Seed some sample data
        db.execSQL("INSERT INTO " + TABLE_BOOKS + " (title, author, status) VALUES ('Data Structures','Cormen','available')");
        db.execSQL("INSERT INTO " + TABLE_BOOKS + " (title, author, status, student_id) VALUES ('DBMS','Ramakrishnan','lent','S001')");
        db.execSQL("INSERT INTO " + TABLE_BOOKS + " (title, author, status, student_id) VALUES ('OS Concepts','Silberschatz','reserved','S002')");
        db.execSQL("INSERT INTO " + TABLE_BOOKS + " (title, author, status) VALUES ('Computer Networks','Tanenbaum','available')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BOOKS);
        onCreate(db);
    }

    // Add a new book
    public long addBook(String title, String author) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_TITLE, title);
        cv.put(COL_AUTHOR, author);
        cv.put(COL_STATUS, "available");
        return db.insert(TABLE_BOOKS, null, cv);
    }

    // Update book status (lent/reserved/available) and student
    public int updateStatus(int bookId, String status, String studentId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_STATUS, status);
        cv.put(COL_STUDENT, studentId);
        return db.update(TABLE_BOOKS, cv, COL_ID + "=?",
                new String[]{String.valueOf(bookId)});
    }

    // Get all books
    public Cursor getAllBooks() {
        return this.getReadableDatabase()
                .rawQuery("SELECT * FROM " + TABLE_BOOKS, null);
    }

    // Get books by status
    public Cursor getBooksByStatus(String status) {
        return this.getReadableDatabase()
                .rawQuery("SELECT * FROM " + TABLE_BOOKS + " WHERE " + COL_STATUS + "=?",
                        new String[]{status});
    }
}
