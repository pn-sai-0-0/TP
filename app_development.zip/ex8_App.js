// Exercise 8: React Native BMI Calculator
// File: App.js (or App.tsx)

import React, { useState } from 'react';
import {
  StyleSheet, Text, View, TextInput,
  TouchableOpacity, ScrollView, StatusBar
} from 'react-native';

export default function App() {
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [bmi, setBmi]       = useState(null);
  const [category, setCat]  = useState('');
  const [color, setColor]   = useState('#333');

  const calculateBMI = () => {
    const w = parseFloat(weight);
    const h = parseFloat(height) / 100; // cm to m
    if (!w || !h || h <= 0) {
      alert('Please enter valid weight and height.');
      return;
    }
    const result = w / (h * h);
    setBmi(result.toFixed(1));

    if (result < 18.5)      { setCat('Underweight'); setColor('#2196F3'); }
    else if (result < 25.0) { setCat('Normal weight'); setColor('#4CAF50'); }
    else if (result < 30.0) { setCat('Overweight'); setColor('#FF9800'); }
    else                    { setCat('Obese'); setColor('#F44336'); }
  };

  const reset = () => {
    setWeight(''); setHeight('');
    setBmi(null); setCat(''); setColor('#333');
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#1a237e"/>

      <View style={styles.header}>
        <Text style={styles.headerText}>BMI Calculator</Text>
        <Text style={styles.subText}>Body Mass Index</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.label}>Weight (kg)</Text>
        <TextInput
          style={styles.input}
          value={weight}
          onChangeText={setWeight}
          keyboardType="numeric"
          placeholder="e.g. 65"
          placeholderTextColor="#aaa"
        />

        <Text style={styles.label}>Height (cm)</Text>
        <TextInput
          style={styles.input}
          value={height}
          onChangeText={setHeight}
          keyboardType="numeric"
          placeholder="e.g. 170"
          placeholderTextColor="#aaa"
        />

        <View style={styles.btnRow}>
          <TouchableOpacity style={styles.btnCalc} onPress={calculateBMI}>
            <Text style={styles.btnText}>Calculate</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.btnReset} onPress={reset}>
            <Text style={[styles.btnText, {color:'#333'}]}>Reset</Text>
          </TouchableOpacity>
        </View>

        {bmi && (
          <View style={styles.result}>
            <Text style={styles.bmiValue}>{bmi}</Text>
            <Text style={[styles.bmiCat, { color }]}>{category}</Text>

            <View style={styles.table}>
              <Text style={styles.tableTitle}>BMI Scale</Text>
              <Text style={styles.row}>{'< 18.5   →  Underweight'}</Text>
              <Text style={styles.row}>{'18.5 - 24.9  →  Normal'}</Text>
              <Text style={styles.row}>{'25.0 - 29.9  →  Overweight'}</Text>
              <Text style={styles.row}>{'≥ 30.0   →  Obese'}</Text>
            </View>
          </View>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flexGrow: 1, backgroundColor: '#e8eaf6' },
  header: {
    backgroundColor: '#1a237e',
    paddingVertical: 32, paddingHorizontal: 24,
    alignItems: 'center'
  },
  headerText: { color: '#fff', fontSize: 28, fontWeight: 'bold' },
  subText: { color: '#9fa8da', fontSize: 14, marginTop: 4 },
  card: {
    margin: 20, backgroundColor: '#fff',
    borderRadius: 12, padding: 24,
    elevation: 4, shadowColor: '#000', shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 }, shadowRadius: 6
  },
  label: { fontSize: 14, fontWeight: '600', color: '#444', marginBottom: 6, marginTop: 12 },
  input: {
    borderWidth: 1, borderColor: '#ddd', borderRadius: 8,
    padding: 12, fontSize: 16, color: '#222'
  },
  btnRow: { flexDirection: 'row', gap: 12, marginTop: 24 },
  btnCalc: {
    flex: 1, backgroundColor: '#1a237e',
    paddingVertical: 14, borderRadius: 8, alignItems: 'center'
  },
  btnReset: {
    flex: 1, backgroundColor: '#e0e0e0',
    paddingVertical: 14, borderRadius: 8, alignItems: 'center'
  },
  btnText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  result: { marginTop: 24, alignItems: 'center' },
  bmiValue: { fontSize: 64, fontWeight: 'bold', color: '#1a237e' },
  bmiCat: { fontSize: 22, fontWeight: '600', marginBottom: 16 },
  table: {
    backgroundColor: '#f5f5f5', borderRadius: 8,
    padding: 14, width: '100%'
  },
  tableTitle: { fontWeight: 'bold', marginBottom: 6, color: '#333' },
  row: { fontSize: 13, color: '#555', paddingVertical: 2 },
});
