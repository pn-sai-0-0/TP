// Exercise 4: Library Database Application - MainActivity
// File: app/src/main/java/com/example/library/MainActivity.java

package com.example.library;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper db;
    ListView listView;
    Button btnAll, btnAvailable, btnLent, btnReserved, btnAdd;
    EditText etTitle, etAuthor;
    ArrayAdapter<String> adapter;
    java.util.List<String> bookList = new java.util.ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db           = new DatabaseHelper(this);
        listView     = findViewById(R.id.listView);
        btnAll       = findViewById(R.id.btnAll);
        btnAvailable = findViewById(R.id.btnAvailable);
        btnLent      = findViewById(R.id.btnLent);
        btnReserved  = findViewById(R.id.btnReserved);
        btnAdd       = findViewById(R.id.btnAdd);
        etTitle      = findViewById(R.id.etTitle);
        etAuthor     = findViewById(R.id.etAuthor);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, bookList);
        listView.setAdapter(adapter);

        loadBooks(null); // load all on start

        btnAll.setOnClickListener(v -> loadBooks(null));
        btnAvailable.setOnClickListener(v -> loadBooks("available"));
        btnLent.setOnClickListener(v -> loadBooks("lent"));
        btnReserved.setOnClickListener(v -> loadBooks("reserved"));

        btnAdd.setOnClickListener(v -> {
            String title  = etTitle.getText().toString().trim();
            String author = etAuthor.getText().toString().trim();
            if (!title.isEmpty() && !author.isEmpty()) {
                db.addBook(title, author);
                etTitle.setText("");
                etAuthor.setText("");
                loadBooks(null);
                Toast.makeText(this, "Book added!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Enter title and author", Toast.LENGTH_SHORT).show();
            }
        });
    }

    void loadBooks(String status) {
        bookList.clear();
        Cursor cursor = (status == null) ? db.getAllBooks() : db.getBooksByStatus(status);
        while (cursor.moveToNext()) {
            String id      = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ID));
            String title   = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_TITLE));
            String author  = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_AUTHOR));
            String sts     = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_STATUS));
            String student = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_STUDENT));
            String entry   = "[" + id + "] " + title + " - " + author + " | " + sts.toUpperCase();
            if (!student.isEmpty()) entry += " (" + student + ")";
            bookList.add(entry);
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }
}
