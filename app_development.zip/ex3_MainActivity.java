// Exercise 3: Send Email and Generate Notifications
// File: app/src/main/java/com/example/emailnotif/MainActivity.java

package com.example.emailnotif;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

public class MainActivity extends AppCompatActivity {

    EditText etTo, etSubject, etBody;
    Button btnSend, btnNotify;
    private static final String CHANNEL_ID = "email_channel";
    private static final int NOTIF_ID = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etTo      = findViewById(R.id.etTo);
        etSubject = findViewById(R.id.etSubject);
        etBody    = findViewById(R.id.etBody);
        btnSend   = findViewById(R.id.btnSend);
        btnNotify = findViewById(R.id.btnNotify);

        createNotificationChannel();

        // Send Email via Intent (opens Gmail / mail app)
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String to      = etTo.getText().toString().trim();
                String subject = etSubject.getText().toString().trim();
                String body    = etBody.getText().toString().trim();

                if (to.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Enter recipient email", Toast.LENGTH_SHORT).show();
                    return;
                }

                Intent emailIntent = new Intent(Intent.ACTION_SEND);
                emailIntent.setType("message/rfc822");
                emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{to});
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
                emailIntent.putExtra(Intent.EXTRA_TEXT, body);

                try {
                    startActivity(Intent.createChooser(emailIntent, "Send Email via:"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "No email app found!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Show Notification (simulates receiving a message)
        btnNotify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showNotification("New Message Received",
                        "You have a new email from sender@example.com");
            }
        });
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Email Notifications",
                    NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Notifications for new emails/messages");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void showNotification(String title, String message) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_email)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);

        NotificationManager manager =
                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(NOTIF_ID, builder.build());
    }
}
