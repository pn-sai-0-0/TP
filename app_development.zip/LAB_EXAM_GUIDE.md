# 📱 Mobile App Lab Exam — All 8 Exercises
## Code + How to Run Guide

---

## ANDROID STUDIO EXERCISES (Ex 1–4)

### ✅ Common Setup for Ex 1–4
1. Open **Android Studio** → New Project → **Empty Views Activity**
2. Language: **Java**, Min SDK: **API 21**
3. Replace `MainActivity.java` with the provided code
4. Replace `res/layout/activity_main.xml` with the provided XML
5. Click **Run ▶** (green play button) → choose emulator or USB device

---

## Exercise 1 — Change Background Color, Font Style, Font Size
**Files:** `ex1_MainActivity.java` + `ex1_activity_main.xml`

**How to run:**
- Copy Java code → `app/src/main/java/com/example/ex1/MainActivity.java`
- Copy XML → `app/src/main/res/layout/activity_main.xml`
- Change package name in `AndroidManifest.xml` to `com.example.ex1`
- Run app → tap 3 buttons to cycle colors, fonts, sizes

**What happens:**
- Button 1: Cycles background color (cyan → yellow → green → gray → white)
- Button 2: Cycles font style (Default → Bold → Monospace → Serif → Sans)
- Button 3: Cycles font size (16 → 20 → 24 → 28 → 32 sp)

---

## Exercise 2 — Calculator
**Files:** `ex2_MainActivity.java` + `ex2_activity_main.xml`

**How to run:**
- Same setup steps as Ex 1 (change package to `com.example.calculator`)
- Run app → fully working calculator with +, -, *, /, decimal, delete

**Key concept:** Implements `View.OnClickListener` interface, reads button text to decide action.

---

## Exercise 3 — Send Email + Notifications
**Files:** `ex3_MainActivity.java` + `ex3_activity_main.xml`

**Extra step — AndroidManifest.xml permissions:**
```xml
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
<uses-permission android:name="android.permission.INTERNET"/>
```

**How to run:**
- Enter recipient email, subject, body → tap **Send Email** → Gmail chooser opens
- Tap **Simulate Incoming Message** → notification appears in status bar

**Note:** On Android 13+ (API 33), notification permission dialog appears automatically.

---

## Exercise 4 — Library Database (SQLite)
**Files:** `ex4_DatabaseHelper.java` + `ex4_MainActivity.java` + `ex4_activity_main.xml`

**How to run:**
- Create two Java files: `DatabaseHelper.java` and `MainActivity.java`
- The database is created automatically on first run (SQLite, no setup needed)
- Tap filter buttons: All / Available / Lent / Reserved
- Add new books using the input fields

**Key concept:** SQLiteOpenHelper manages local DB. Pre-seeded with 4 books on first run.

---

## CORDOVA EXERCISES (Ex 5–6)

### ✅ Common Setup for Ex 5–6
```bash
# Install Cordova globally (one time)
npm install -g cordova

# Create project
cordova create myapp com.example.myapp MyApp
cd myapp

# Add Android platform
cordova platform add android

# Build and run
cordova run android
```

**Put your HTML file at:** `www/index.html`

---

## Exercise 5 — Cordova Login Screen
**File:** `ex5_cordova_login.html` → paste into `www/index.html`

**How to run:**
```bash
cordova platform add android
cordova run android
```
- **Test credentials:** username = `admin`, password = `1234`
- Reset button clears all fields

**Features:** Header icon, username + password inputs, reset + submit buttons, validation message

---

## Exercise 6 — Cordova Geolocation
**File:** `ex6_cordova_location.html` → paste into `www/index.html`

**Extra step — add geolocation plugin:**
```bash
cordova plugin add cordova-plugin-geolocation
```

**Add permission in `config.xml`:**
```xml
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
```

**How to run:**
```bash
cordova run android
```
- Tap **Get My Location** → grants permission → shows lat/lon/accuracy
- Tap the Google Maps link to open exact location on map

---

## IONIC EXERCISE (Ex 7)

### ✅ Setup for Ex 7
```bash
# Install Ionic CLI (one time)
npm install -g @ionic/cli

# Create project
ionic start RecipeApp blank --type=angular
cd RecipeApp

# Run in browser (fastest for demo)
ionic serve

# Run on Android
ionic capacitor add android
ionic capacitor run android
```

---

## Exercise 7 — Ionic Recipe Suggester
**Files:** `ex7_home.page.html` + `ex7_home.page.ts`

**Paste into:**
- `src/app/home/home.page.html`
- `src/app/home/home.page.ts`

**Also add `FormsModule` to `home.module.ts`:**
```typescript
import { FormsModule } from '@angular/forms';
imports: [CommonModule, FormsModule, IonicModule, HomePageRoutingModule]
```

**How to run:** `ionic serve` → opens in browser at localhost:8100

**Features:**
- Type ingredients (egg, tomato, rice, banana, pasta, etc.) → Add
- Tap **Suggest Recipes** → shows matching recipes with instructions + nutrition

---

## REACT NATIVE EXERCISE (Ex 8)

### ✅ Setup for Ex 8
```bash
# Install React Native CLI (one time)
npm install -g react-native-cli

# Create project (choose blank template)
npx create-expo-app BMIApp
# OR without Expo:
npx react-native init BMIApp

cd BMIApp

# Run on Android
npx react-native run-android
# OR with Expo:
npx expo start
```

---

## Exercise 8 — React Native BMI Calculator
**File:** `ex8_App.js` → replace `App.js` in project root

**How to run:**
```bash
cd BMIApp
npx expo start   # scan QR code with Expo Go app on phone
```
OR
```bash
npx react-native run-android
```

**How to use:**
- Enter weight (kg) and height (cm)
- Tap **Calculate** → shows BMI value + category (color-coded)
- Tap **Reset** to clear

**BMI categories shown:**
- 🔵 < 18.5 → Underweight
- 🟢 18.5–24.9 → Normal
- 🟡 25–29.9 → Overweight
- 🔴 ≥ 30 → Obese

---

## 📋 Quick Tips for Lab Exam

| Exercise | Platform | Key Classes/Concepts |
|---|---|---|
| Ex 1 | Android Studio | `setBackgroundColor`, `setTypeface`, `setTextSize` |
| Ex 2 | Android Studio | `View.OnClickListener`, `onClick` switch |
| Ex 3 | Android Studio | `Intent.ACTION_SEND`, `NotificationCompat.Builder` |
| Ex 4 | Android Studio | `SQLiteOpenHelper`, `ContentValues`, `Cursor` |
| Ex 5 | Cordova | HTML form, `navigator.geolocation`, layout managers |
| Ex 6 | Cordova | `cordova-plugin-geolocation`, `getCurrentPosition` |
| Ex 7 | Ionic/Angular | `[(ngModel)]`, `*ngFor`, `ion-card`, `ion-chip` |
| Ex 8 | React Native | `useState`, `TextInput`, `TouchableOpacity`, `StyleSheet` |

---

*Good luck in your lab exam tomorrow! 🚀*
