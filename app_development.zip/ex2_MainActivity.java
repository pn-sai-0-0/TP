// Exercise 2: Calculator Application
// File: app/src/main/java/com/example/calculator/MainActivity.java

package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView display;
    String currentInput = "";
    double firstNum = 0, secondNum = 0;
    String operator = "";
    boolean isOperatorPressed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);

        int[] buttonIds = {
            R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
            R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9,
            R.id.btnDot, R.id.btnAdd, R.id.btnSub, R.id.btnMul, R.id.btnDiv,
            R.id.btnEquals, R.id.btnClear, R.id.btnDel
        };

        for (int id : buttonIds) {
            findViewById(id).setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View v) {
        Button btn = (Button) v;
        String btnText = btn.getText().toString();

        switch (btnText) {
            case "C":
                currentInput = "";
                firstNum = 0;
                secondNum = 0;
                operator = "";
                display.setText("0");
                break;
            case "⌫":
                if (!currentInput.isEmpty()) {
                    currentInput = currentInput.substring(0, currentInput.length() - 1);
                    display.setText(currentInput.isEmpty() ? "0" : currentInput);
                }
                break;
            case "=":
                if (!operator.isEmpty() && !currentInput.isEmpty()) {
                    secondNum = Double.parseDouble(currentInput);
                    double result = calculate();
                    // show integer if no decimal needed
                    if (result == (long) result)
                        display.setText(String.valueOf((long) result));
                    else
                        display.setText(String.valueOf(result));
                    currentInput = display.getText().toString();
                    operator = "";
                }
                break;
            case "+": case "-": case "*": case "/":
                if (!currentInput.isEmpty()) {
                    firstNum = Double.parseDouble(currentInput);
                    operator = btnText;
                    currentInput = "";
                }
                break;
            default: // digits and dot
                if (btnText.equals(".") && currentInput.contains(".")) break;
                currentInput += btnText;
                display.setText(currentInput);
                break;
        }
    }

    double calculate() {
        switch (operator) {
            case "+": return firstNum + secondNum;
            case "-": return firstNum - secondNum;
            case "*": return firstNum * secondNum;
            case "/": return (secondNum != 0) ? firstNum / secondNum : 0;
        }
        return 0;
    }
}
