// Exercise 7: Ionic Recipe Suggester
// File: src/app/home/home.page.ts

import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  currentIngredient = '';
  ingredients: string[] = [];
  suggestedRecipes: any[] = [];
  noMatch = false;

  // Recipe database
  recipeDb = [
    {
      name: 'Scrambled Eggs',
      category: 'Breakfast',
      keywords: ['egg', 'butter', 'milk'],
      instructions: '1. Crack eggs into bowl. 2. Add milk and whisk. 3. Melt butter in pan. 4. Pour mixture, stir gently until cooked.',
      nutrition: { calories: '220 kcal', protein: '14g', carbs: '2g', fat: '17g' }
    },
    {
      name: 'Tomato Omelette',
      category: 'Breakfast',
      keywords: ['egg', 'tomato', 'onion'],
      instructions: '1. Beat eggs. 2. Sauté diced tomato and onion. 3. Pour eggs over veggies. 4. Fold and serve.',
      nutrition: { calories: '180 kcal', protein: '12g', carbs: '6g', fat: '12g' }
    },
    {
      name: 'Pasta Pomodoro',
      category: 'Lunch',
      keywords: ['pasta', 'tomato', 'garlic'],
      instructions: '1. Cook pasta. 2. Sauté garlic in olive oil. 3. Add chopped tomatoes. 4. Toss pasta in sauce and serve.',
      nutrition: { calories: '350 kcal', protein: '10g', carbs: '65g', fat: '8g' }
    },
    {
      name: 'Veggie Fried Rice',
      category: 'Lunch',
      keywords: ['rice', 'egg', 'onion', 'carrot'],
      instructions: '1. Cook rice. 2. Scramble eggs in wok. 3. Add veggies and rice. 4. Season with soy sauce and stir-fry.',
      nutrition: { calories: '300 kcal', protein: '9g', carbs: '52g', fat: '7g' }
    },
    {
      name: 'Banana Smoothie',
      category: 'Snack',
      keywords: ['banana', 'milk'],
      instructions: '1. Peel banana. 2. Add banana and milk to blender. 3. Blend until smooth. 4. Serve chilled.',
      nutrition: { calories: '150 kcal', protein: '4g', carbs: '30g', fat: '2g' }
    },
  ];

  addIngredient() {
    const ing = this.currentIngredient.trim().toLowerCase();
    if (ing && !this.ingredients.includes(ing)) {
      this.ingredients.push(ing);
    }
    this.currentIngredient = '';
  }

  removeIngredient(ing: string) {
    this.ingredients = this.ingredients.filter(i => i !== ing);
  }

  suggestRecipes() {
    this.suggestedRecipes = this.recipeDb.filter(recipe =>
      recipe.keywords.some(kw => this.ingredients.includes(kw))
    );
    this.noMatch = this.suggestedRecipes.length === 0;
  }
}
