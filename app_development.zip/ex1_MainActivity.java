// Exercise 1: Change Background Color, Font Style and Font Size on Button Click
// File: app/src/main/java/com/example/ex1/MainActivity.java

package com.example.ex1;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    LinearLayout layout;
    TextView textView;
    Button btnColor, btnFont, btnSize;
    int colorIndex = 0, fontIndex = 0, sizeIndex = 0;

    int[] colors = {Color.CYAN, Color.YELLOW, Color.GREEN, Color.LTGRAY, Color.WHITE};
    int[] sizes = {16, 20, 24, 28, 32};
    Typeface[] fonts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        layout   = findViewById(R.id.layout);
        textView = findViewById(R.id.textView);
        btnColor = findViewById(R.id.btnColor);
        btnFont  = findViewById(R.id.btnFont);
        btnSize  = findViewById(R.id.btnSize);

        fonts = new Typeface[]{
            Typeface.DEFAULT,
            Typeface.DEFAULT_BOLD,
            Typeface.MONOSPACE,
            Typeface.SERIF,
            Typeface.SANS_SERIF
        };

        btnColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                colorIndex = (colorIndex + 1) % colors.length;
                layout.setBackgroundColor(colors[colorIndex]);
            }
        });

        btnFont.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fontIndex = (fontIndex + 1) % fonts.length;
                textView.setTypeface(fonts[fontIndex]);
            }
        });

        btnSize.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sizeIndex = (sizeIndex + 1) % sizes.length;
                textView.setTextSize(sizes[sizeIndex]);
            }
        });
    }
}
